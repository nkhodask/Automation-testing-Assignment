package PageObject;

import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CheckoutPageObject {
	
	
	private WebDriver driver;
	
	public CheckoutPageObject(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id = "#logoimage")
	WebElement logo;
	
	@FindBy(css = ".amount strong")
	WebElement amount;
	
	@FindBy(css = "#paymentoptionslist button div")
	List<WebElement> payments;
	
	public String LandingPage()
	{
		return driver.getTitle();
	}
	
	public String VerifyAmountforPayment()
	{
		return amount.getText();
		
	}
	
	public void ClickOnPaymentMethod(String paymentMethod)
	{
		for(WebElement pay : payments )
		{
			if(pay.getText().equals(paymentMethod))
			{
				pay.click();
				break;
			}
		}
	}
	
}
