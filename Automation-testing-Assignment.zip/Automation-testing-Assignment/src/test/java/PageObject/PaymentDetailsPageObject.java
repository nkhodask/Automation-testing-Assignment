package PageObject;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import mainTest.Utilities;

public class PaymentDetailsPageObject {
	
	private WebDriver driver;
	Utilities utility = new Utilities();
	
	public PaymentDetailsPageObject(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id = "cardNumber")
	WebElement cardTextBox;
	
	@FindBy(id = "expiryDate")
	WebElement expDateTextBox;
	
	@FindBy(id = "cvv")
	WebElement cvvTextBox;
	
	@FindBy(id = "primaryButton")
	WebElement payButton;
	
	@FindBy(id = "secondaryButton")
	WebElement cancelButton;
	
	@FindBy(id = "expiryDate-error")
	WebElement expiryError;
	
	@FindBy(id = "cardNumber-error")
	WebElement cardError;
	
	@FindBy(id = "cvv-error")
	WebElement cvvError;
	
	@FindBy(id = "cvv-popover")
	WebElement cvvHover;
	
	@FindBy(css = "div.popover-content-close")
	WebElement popClose;
	
	@FindBy(css = "div#remembermeBlock .icon-qmark")
	WebElement remMePopButton;
	
	@FindBy(xpath = "//div[@id='remembermeBlock']/label/following-sibling::span")
	WebElement remMePopText;
	
	@FindBy(css = "#paymentoptionswrapper h2")
	WebElement paymentHeader;
	
	@FindBy(css = "#paymentoptionswrapper p")
	WebElement paymentSubHeader;
	
	@FindBy(id = "tryagainbutton")
	WebElement tryAgainButton;
	
	@FindBy(id = "selectotherbuttontext")
	WebElement tryOtherButton;
	
	@FindBy(id="emailAddress")
	WebElement emailTextBox;
	
	@FindBy(id="phoneNumber")
	WebElement phoneTextBox;
	
	public String VerifyPayment()
	{
		return paymentHeader.getText();
	}
	
	public void TryAnotherMethod()
	{
		tryOtherButton.click();
	}
	
	public void EnterPaymentDetails(String email, String phone)
    {	
		emailTextBox.sendKeys(email);
		phoneTextBox.sendKeys(phone);
		
		utility.ScreenCapture(driver);
		
		payButton.click();
    }
	
	public String EnterPaymentDetailsforCard(String cardNumber, String expiryDate, String cvv)
    {
        ((JavascriptExecutor)driver).executeScript("document.getElementById('cardNumber').value='"+cardNumber+"';");
        cardTextBox.click();
        
        ((JavascriptExecutor)driver).executeScript("document.getElementById('expiryDate').value='"+expiryDate+"';");
        expDateTextBox.click();
        
        cvvTextBox.sendKeys(cvv);

        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("cc-image")));
        
        utility.ScreenCapture(driver);
        
        payButton.click();
        
        return paymentSubHeader.getText();

    }
	
}
