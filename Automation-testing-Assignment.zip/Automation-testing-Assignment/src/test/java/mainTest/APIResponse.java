package mainTest;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Map;
import java.util.UUID;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONObject;

public class APIResponse {
	
	Utilities utility = new Utilities();
	
	public String GetRedirectUrl() 
	{ 
		Map<String,String> propertiesMap = utility.ReadProperties();
		
		String redirectUrl = "";
		String messageUuid = UUID.randomUUID().toString();
        String requestUuid = UUID.randomUUID().toString();
        
		//Get Date : Start
		String date = utility.GetCurrentDate();
		
		//Generate Signature
		
		String postString = propertiesMap.get("post") + propertiesMap.get("newLine") + propertiesMap.get("content") + propertiesMap.get("newLine") + date + propertiesMap.get("newLine") + propertiesMap.get("appIdentifier") + propertiesMap.get("newLine") + propertiesMap.get("messageid")+messageUuid + propertiesMap.get("newLine") + propertiesMap.get("requestid")+requestUuid + propertiesMap.get("newLine") + propertiesMap.get("relativeUrl") + propertiesMap.get("newLine");
		
		String hash = utility.GenerateSignature(postString);
		
		//Region Create JSON : STart
		JSONObject postJSON = utility.GetJSONDataToPost();
		
		//POST
		 
		String authKey = propertiesMap.get("staticPartAuth") + hash;
		HttpPost post = new HttpPost(propertiesMap.get("postUrl"));
		  try
		  {
	        String jsonData=postJSON.toString();
            post.setHeader("AUTHORIZATION", authKey);
            post.setHeader("Content-Type", "application/json");
            post.setHeader("Accept", "application/json");
            post.setHeader("Date",date);
   			post.addHeader("x-gcs-applicationidentifier", "globalcollect-api-explorer");
   			post.addHeader("x-gcs-messageid", messageUuid);
   			post.addHeader("x-gcs-requestid", requestUuid);
   		
   			HttpResponse response=null;
            String line = "";
            StringBuffer result = new StringBuffer();
            post.setEntity(new StringEntity(jsonData));
            HttpClient client = HttpClientBuilder.create().build();
            response = client.execute(post);
           
            BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
            while ((line = reader.readLine()) != null){ result.append(line); }
           
            //Getting Url from Response
            JSONObject obj = new JSONObject(result.toString());
	        redirectUrl = obj.getString("partialRedirectUrl");
           
		  }
		  catch (UnsupportedEncodingException e){
			  e.printStackTrace();
         }
         catch (IOException e){
        	 e.printStackTrace();
         }
         catch(Exception e){
        	 e.printStackTrace();
         }
         finally{
       	  post.releaseConnection();
         }
		  
		  return redirectUrl;
	}
}
