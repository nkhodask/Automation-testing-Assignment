package mainTest;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.json.JSONObject;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

public class Utilities {
	
	public String GetCurrentDate()
	{
		//Getting Date
		Date curDate = new Date();
	    
	    SimpleDateFormat format = new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z");
	    TimeZone gmtTime = TimeZone.getTimeZone("GMT");
	    format.setTimeZone(gmtTime);
	    
	    String dateToPost = format.format(curDate);
	    
	    return dateToPost;
	}
	
	public String GenerateSignature(String postString)
	{
		String authKey = "";
		
		//HMAC Algorithm
		try 
		{
			 String secret = ReadProperties().get("secret");
		     String message = postString;

		     Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
		     SecretKeySpec secret_key = new SecretKeySpec(secret.getBytes(), "HmacSHA256");
		     sha256_HMAC.init(secret_key);

		     authKey = Base64.encodeBase64String(sha256_HMAC.doFinal(message.getBytes()));
		 }
	    catch (Exception e){
	    	e.printStackTrace();
	    }
		
		return authKey;
	}
	
	public JSONObject GetJSONDataToPost()
	{
		JSONObject amount = new JSONObject();
		 amount.put("currencyCode", ReadProperties().get("currencyCode"));
		 amount.put("amount", ReadProperties().get("amount"));
		
		 JSONObject billAdd = new JSONObject();
		 billAdd.put("countryCode", ReadProperties().get("countryCode"));
		 
		 JSONObject customer = new JSONObject();
		 customer.put("billingAddress", billAdd);
		 customer.put("merchantCustomerId", ReadProperties().get("merchantCustomerId"));
		 
		 JSONObject order = new JSONObject();
		 order.put("amountOfMoney", amount);
		 order.put("customer", customer);
		
		 JSONObject hostedCheckout = new JSONObject();
		 hostedCheckout.put("variant", ReadProperties().get("variant"));
		 hostedCheckout.put("locale", ReadProperties().get("locale"));
		 
		 JSONObject postJSON = new JSONObject();
		 postJSON.put("order", order);
		 postJSON.put("hostedCheckoutSpecificInput", hostedCheckout);
		 
		 return postJSON;
	}
	
	public Map<String,String> ReadProperties()
	{
		 Map<String,String> propertiesMap = new HashMap<String,String>();
		
		//Reading Properties
		try 
		{
			File file = new File(System.getProperty("user.dir") + "/src/test/resources/config.properties");
			FileInputStream fileInput = new FileInputStream(file);
			Properties properties = new Properties();
			properties.load(fileInput);
			fileInput.close();

			@SuppressWarnings("rawtypes")
			Enumeration enuKeys = properties.keys();
			while (enuKeys.hasMoreElements()) {
				
				String key = (String) enuKeys.nextElement();
				String value = properties.getProperty(key);
				propertiesMap.put(key, value);
			}	
		
		} 
		catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		
		return propertiesMap;
				
	}

	public void ScreenCapture(WebDriver driver)
	{
		try 
		{
			File srcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
			File screenshotName = new File(System.getProperty("user.dir") + "/Screenshots/" + timeStamp + ".png");
			FileUtils.copyFile(srcFile, screenshotName);
			
			String filePath = screenshotName.toString();
			String path = "<img src=\"file://" + filePath + "\" alt=\"\"/>";
			Reporter.log(path);
		} 
		catch (IOException e) {
			
			e.printStackTrace();
		}
	}
}
