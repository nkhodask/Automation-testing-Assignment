package mainTest;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.Reporter;

import java.util.Map;
import java.util.concurrent.TimeUnit;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.asserts.SoftAssert;

import PageObject.CheckoutPageObject;
import PageObject.PaymentDetailsPageObject;


public class IngenicoTest {
	
	APIResponse apiResponse = new APIResponse();
	Utilities utility = new Utilities();
	WebDriver driver;
	CheckoutPageObject chcekoutObj;
	PaymentDetailsPageObject paymentObj;
	SoftAssert soft = new SoftAssert();
	Map<String,String> propertiesMap = utility.ReadProperties();
	
	@BeforeTest
	public void Setup()
	{ 
		
		String url = propertiesMap.get("staticUrl") + apiResponse.GetRedirectUrl();
		
		//Run Chrome in headless mode
		ChromeOptions options = new ChromeOptions();
		options.setHeadless(true);
		options.addArguments("window-size=1200x600");
		
		driver = new ChromeDriver(options);
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/chromedriver");
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		chcekoutObj = new CheckoutPageObject(driver);
		paymentObj = new PaymentDetailsPageObject(driver);
	}
	
	@Test(priority=1)
	public void LandingPage()
	{
		Reporter.log(propertiesMap.get("logLandingPage"));
		String actualText = propertiesMap.get("title");
		utility.ScreenCapture(driver);
		AssertJUnit.assertEquals(actualText, chcekoutObj.LandingPage());
	}
	
	@Test(priority=2)
	public void SelectPayment()
	{
		Reporter.log(propertiesMap.get("logPaymentMethod"));
		chcekoutObj = new CheckoutPageObject(driver);
		utility.ScreenCapture(driver);
		chcekoutObj.ClickOnPaymentMethod(propertiesMap.get("paymentFirst"));
		
	}
	
	@Test(priority=3)
	public void VerifyPayAmount()
	{
		Reporter.log(propertiesMap.get("logVerifyAmount"));
		AssertJUnit.assertEquals(propertiesMap.get("amountToPay"), chcekoutObj.VerifyAmountforPayment());
	}
	
	@Test(priority=4)
	public void VerifyPaymentFailure()
	{
		Reporter.log(propertiesMap.get("logPayFailure"));
		String actualText = propertiesMap.get("failure");
		AssertJUnit.assertEquals(paymentObj.VerifyPayment(),actualText);
		
		utility.ScreenCapture(driver);
	}
	
	@Test(priority=5)
	public void TryAnotherMethod()
	{
		Reporter.log(propertiesMap.get("logOtherMethod") + propertiesMap.get("paymentSeond"));
		paymentObj.TryAnotherMethod();
		chcekoutObj.ClickOnPaymentMethod(propertiesMap.get("paymentSeond"));
		paymentObj.EnterPaymentDetails(propertiesMap.get("email"), propertiesMap.get("phone"));
		
		AssertJUnit.assertEquals(paymentObj.VerifyPayment(),propertiesMap.get("failure"));
	}
	
	@Test(priority=6)
	public void CardPayment()
	{
		Reporter.log(propertiesMap.get("logPaySuccessful") + propertiesMap.get("paymentThird"));
		paymentObj.TryAnotherMethod();
		chcekoutObj.ClickOnPaymentMethod(propertiesMap.get("paymentThird"));
		String status = paymentObj.EnterPaymentDetailsforCard(propertiesMap.get("cardNumber")
								, propertiesMap.get("expDate"), propertiesMap.get("cvv"));
		
		utility.ScreenCapture(driver);
		
		String actualText = propertiesMap.get("success");
		AssertJUnit.assertEquals(status,actualText);
	}
	
	
	@AfterTest
	public void CLose()
	{
		driver.quit();
	}
}
